<?php
require_once 'cek_akses.php';
require_once 'config/koneksi.php';
require_once 'config/koneksi.php';
cek_role(['admin']);

$opsi = require 'opsi_wali_kelas.php';
halaman_form($koneksi, 't_wali_kelas', $opsi, 'ubah');
