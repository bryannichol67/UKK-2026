<?php
require_once 'cek_akses.php';
require_once 'config/koneksi.php';
require_once 'config/koneksi.php';
cek_role(['guru']);

$opsi = require 'opsi_catatan_pelanggaran.php';
halaman_form($koneksi, 't_pelanggaran_siswa', $opsi, 'tambah');
