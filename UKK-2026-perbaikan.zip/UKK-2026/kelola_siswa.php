
<?php
require_once 'cek_akses.php';
require_once 'config/koneksi.php';
require_once 'config/koneksi.php';

cek_role(['admin']);

$opsi = require 'opsi_siswa.php';
mulai_sesi();

// Pesan hasil dari halaman proses tambah/edit
$pesan = $_SESSION['pesan'] ?? '';
unset($_SESSION['pesan']);

// Proses hapus
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    ($_POST['aksi'] ?? '') === 'hapus'
) {
    $pesan = simpan_data(
        $koneksi,
        't_siswa',
        $opsi,
        'hapus',
        $_POST
    )['pesan'];
}

// Deteksi otomatis kolom nama kelas
$kolomKelas = nama_aman(
    kolom_nama_tampil($koneksi, 't_kelas')
);

// Ambil data siswa dan kelas terbaru
$data = mysqli_query(
    $koneksi,
    "SELECT
        s.id,
        s.nisn,
        s.nama,
        s.jenis_kelamin,
        s.tanggal_lahir,
        k.`$kolomKelas` AS kelas
    FROM t_siswa s
    LEFT JOIN t_kelas_siswa ks
        ON ks.id = (
            SELECT MAX(id)
            FROM t_kelas_siswa
            WHERE siswa_id = s.id
        )
    LEFT JOIN t_kelas k
        ON k.id = ks.kelas_id
    ORDER BY s.id DESC
    LIMIT 100"
);

function h($v) {
    return htmlspecialchars(
        (string) $v,
        ENT_QUOTES,
        'UTF-8'
    );
}
?>

<link rel="stylesheet"
      href="https://cdn.datatables.net/2.3.4/css/dataTables.dataTables.min.css">

<h2>Data Siswa</h2>

<p class="mb-3">
    <a class="btn btn-primary" href="tambah_data_siswa.php">
        + Tambah data
    </a>
</p>

<?php if ($pesan !== ''): ?>
    <div class="alert alert-info">
        <?= h($pesan) ?>
    </div>
<?php endif; ?>

<div class="table-responsive">
    <table id="tabelSiswa"
           class="table table-bordered table-hover align-middle">

        <thead class="thead-dark">
            <tr>
                <th>No</th>
                <th>NISN</th>
                <th>Nama</th>
                <th>JK</th>
                <th>Kelas</th>
                <th>Tanggal Lahir</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>
            <?php
            $no = 1;

            if ($data):
                while ($row = mysqli_fetch_assoc($data)):
            ?>
                <tr>
                    <td><?= $no++ ?></td>

                    <td><?= h($row['nisn']) ?></td>

                    <td><?= h($row['nama']) ?></td>

                    <td><?= h($row['jenis_kelamin']) ?></td>

                    <td><?= h($row['kelas']) ?></td>

                    <td>
                        <?= !empty($row['tanggal_lahir'])
                            ? h(date(
                                'd-m-Y',
                                strtotime($row['tanggal_lahir'])
                            ))
                            : '' ?>
                    </td>

                    <td>
                        <form method="post"
                              style="display:inline"
                              onsubmit="return confirm('Hapus data ini?')">

                            <input type="hidden"
                                   name="aksi"
                                   value="hapus">

                            <input type="hidden"
                                   name="id"
                                   value="<?= (int) $row['id'] ?>">

                            <button type="submit"
                                    class="btn btn-sm btn-danger">
                                Hapus
                            </button>
                        </form>

                        <a class="btn btn-sm btn-warning"
                           href="edit_data_siswa.php?id=<?= (int) $row['id'] ?>">
                            Edit
                        </a>
                    </td>
                </tr>
            <?php
                endwhile;
            endif;
            ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<script src="https://cdn.datatables.net/2.3.4/js/dataTables.min.js"></script>

<script>
$(document).ready(function () {
    $('#tabelSiswa').DataTable({
        pageLength: 10,
        lengthMenu: [5, 10, 25, 50],
        ordering: true,
        searching: true,
        language: {
            search: "Cari:",
            lengthMenu: "Tampilkan _MENU_ data",
            info: "Menampilkan _START_ sampai _END_ dari _TOTAL_ data",
            infoEmpty: "Tidak ada data",
            infoFiltered: "(difilter dari _MAX_ total data)",
            zeroRecords: "Data tidak ditemukan",
            emptyTable: "Belum ada data siswa",
            paginate: {
                first: "Pertama",
                last: "Terakhir",
                next: "Selanjutnya",
                previous: "Sebelumnya"
            }
        },
        columnDefs: [
            {
                targets: 6,
                orderable: false,
                searchable: false
            }
        ]
    });
});
</script>
