<?php
require_once 'cek_akses.php';
require_once 'config/koneksi.php';
require_once 'config/koneksi.php';
cek_role(['admin']);

$opsi = require 'opsi_tahun_ajaran.php';
proses_halaman($koneksi, 't_tahun_ajaran', $opsi, 'ubah');
